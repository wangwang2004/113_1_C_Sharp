﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Program4_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double totalCalories = double.Parse(txtTotalCalories.Text);
                double fatGrams = double.Parse(txtFatGrams.Text);

                double fatCalories = fatGrams * 9;
                double fatPercentage = (fatCalories / totalCalories) * 100;

                lblResult.Text = $"脂肪卡路里數: {fatCalories}\n";
                lblResult.Text += $"來自脂肪的卡路里百分比: {fatPercentage:0.00}%";

                if (radioButton1.Checked)
                {
                    lblResult.Text += $"\n該食物是否為低脂: {(fatPercentage < 30 ? "是" : "否")}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("請輸入有效的數字！", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }

